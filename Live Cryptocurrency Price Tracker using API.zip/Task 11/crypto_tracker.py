

import requests
import time
import os
from datetime import datetime

# Optional imports for bonus features
try:
    import matplotlib.pyplot as plt
    MATPLOTLIB_AVAILABLE = True
except ImportError:
    MATPLOTLIB_AVAILABLE = False

class CryptoPriceTracker:
    """Main class for cryptocurrency price tracking"""
    
    def __init__(self):
        """Initialize the tracker with default settings"""
        self.base_url = "https://api.coingecko.com/api/v3"
        self.cryptocurrencies = []
        self.currency = "usd"
        self.price_history = {}
        self.refresh_interval = 10  # seconds
        
    def get_available_coins(self):
        """Fetch list of all available cryptocurrencies"""
        try:
            url = f"{self.base_url}/coins/list"
            response = requests.get(url, timeout=10)
            response.raise_for_status()
            return response.json()
        except requests.RequestException as e:
            print(f"❌ Error fetching coin list: {e}")
            return []
    
    def search_coin(self, search_term):
        """Search for a cryptocurrency by name or symbol"""
        coins = self.get_available_coins()
        if not coins:
            return []
        
        search_term = search_term.lower()
        results = []
        
        for coin in coins:
            if (search_term in coin['name'].lower() or 
                search_term in coin['symbol'].lower()):
                results.append(coin)
                if len(results) >= 10:  # Limit results
                    break
        
        return results
    
    def add_cryptocurrency(self, coin_id, coin_name):
        """Add a cryptocurrency to track"""
        if coin_id not in [c['id'] for c in self.cryptocurrencies]:
            self.cryptocurrencies.append({
                'id': coin_id,
                'name': coin_name,
                'price_history': []
            })
            self.price_history[coin_id] = []
            return True
        return False
    
    def remove_cryptocurrency(self, index):
        """Remove a cryptocurrency by index"""
        if 0 <= index < len(self.cryptocurrencies):
            removed = self.cryptocurrencies.pop(index)
            del self.price_history[removed['id']]
            return True
        return False
    
    def fetch_prices(self):
        """Fetch current prices for all tracked cryptocurrencies"""
        if not self.cryptocurrencies:
            return {}
        
        coin_ids = ','.join([c['id'] for c in self.cryptocurrencies])
        
        try:
            url = f"{self.base_url}/simple/price"
            params = {
                'ids': coin_ids,
                'vs_currencies': self.currency,
                'include_24hr_change': 'true',
                'include_last_updated_at': 'true'
            }
            
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            data = response.json()
            
            # Update price history
            for coin_id, coin_data in data.items():
                if coin_id in self.price_history:
                    price = coin_data.get(self.currency, 0)
                    self.price_history[coin_id].append({
                        'price': price,
                        'timestamp': datetime.now()
                    })
                    # Keep only last 100 records
                    if len(self.price_history[coin_id]) > 100:
                        self.price_history[coin_id].pop(0)
            
            return data
            
        except requests.RequestException as e:
            print(f"❌ API Error: {e}")
            return {}
    
    def display_prices(self, prices_data):
        """Display prices in a formatted table"""
        if not prices_data:
            print("\n⚠️  No price data available. Please check your internet connection.\n")
            return
        
        # Clear screen for better visibility
        os.system('cls' if os.name == 'nt' else 'clear')
        
        print("\n" + "=" * 80)
        print(f" 🚀 LIVE CRYPTOCURRENCY PRICE TRACKER ")
        print(f" 📅 Last Updated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f" 💵 Currency: {self.currency.upper()}")
        print(f" 🔄 Auto-refresh every {self.refresh_interval} seconds")
        print("=" * 80)
        
        # Table header
        print(f"\n{'#':<3} {'Coin':<15} {'Price':<15} {'24h Change':<12} {'Status':<10}")
        print("-" * 80)
        
        for idx, coin in enumerate(self.cryptocurrencies, 1):
            coin_id = coin['id']
            coin_name = coin['name']
            
            if coin_id in prices_data:
                price = prices_data[coin_id].get(self.currency, 'N/A')
                change = prices_data[coin_id].get(f'{self.currency}_24h_change', 0)
                
                # Format price
                if price != 'N/A':
                    if price >= 1000:
                        price_str = f"${price:,.2f}"
                    else:
                        price_str = f"${price:.4f}"
                else:
                    price_str = "N/A"
                
                # Format change with color indicator
                if change > 0:
                    change_str = f"📈 +{change:.2f}%"
                    status = "🟢 Bullish"
                elif change < 0:
                    change_str = f"📉 {change:.2f}%"
                    status = "🔴 Bearish"
                else:
                    change_str = f"{change:.2f}%"
                    status = "⚪ Stable"
                
                print(f"{idx:<3} {coin_name:<15} {price_str:<15} {change_str:<12} {status:<10}")
            else:
                print(f"{idx:<3} {coin_name:<15} {'N/A':<15} {'N/A':<12} {'❌ Error':<10}")
        
        print("\n" + "=" * 80)
        print("Commands: [R]efresh | [A]dd | [D]elete | [T]rend | [S]ave | [Q]uit")
        print("=" * 80)
    
    def plot_trend(self, coin_id, coin_name):
        """Plot price trend graph (Bonus feature)"""
        if not MATPLOTLIB_AVAILABLE:
            print("\n❌ Matplotlib not installed. Run: pip install matplotlib\n")
            return
        
        if coin_id not in self.price_history or len(self.price_history[coin_id]) < 2:
            print("\n⚠️  Not enough price history data to plot trend\n")
            return
        
        history = self.price_history[coin_id]
        prices = [h['price'] for h in history]
        timestamps = [h['timestamp'] for h in history]
        
        plt.figure(figsize=(10, 6))
        plt.plot(timestamps, prices, marker='o', linewidth=2, markersize=4)
        plt.title(f'{coin_name} Price Trend ({self.currency.upper()})')
        plt.xlabel('Time')
        plt.ylabel(f'Price ({self.currency.upper()})')
        plt.grid(True, alpha=0.3)
        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.show()
    
    def save_to_csv(self):
        """Save current prices to CSV file (Bonus feature)"""
        if not self.cryptocurrencies:
            print("\n⚠️  No cryptocurrencies to save\n")
            return
        
        import csv
        filename = f"crypto_prices_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        
        try:
            prices_data = self.fetch_prices()
            with open(filename, 'w', newline='') as csvfile:
                writer = csv.writer(csvfile)
                writer.writerow(['Coin', f'Price ({self.currency.upper()})', '24h Change (%)', 'Timestamp'])
                
                for coin in self.cryptocurrencies:
                    coin_id = coin['id']
                    coin_name = coin['name']
                    
                    if coin_id in prices_data:
                        price = prices_data[coin_id].get(self.currency, 'N/A')
                        change = prices_data[coin_id].get(f'{self.currency}_24h_change', 'N/A')
                        writer.writerow([coin_name, price, change, datetime.now().strftime('%Y-%m-%d %H:%M:%S')])
            
            print(f"\n✅ Data saved to {filename}\n")
        except Exception as e:
            print(f"\n❌ Error saving to CSV: {e}\n")
    
    def set_alert(self, coin_id, target_price):
        """Set price alert (Bonus feature)"""
        # Simplified alert system - checks once
        prices_data = self.fetch_prices()
        if coin_id in prices_data:
            current_price = prices_data[coin_id].get(self.currency, 0)
            if current_price >= target_price:
                print(f"\n🔔 ALERT: {coin_id} has reached ${target_price}! Current: ${current_price}\n")
                return True
        return False
    
    def run(self):
        """Main application loop"""
        print("\n" + "🎯" * 20)
        print(" WELCOME TO CRYPTO PRICE TRACKER ")
        print("🎯" * 20)
        
        # Add some default cryptocurrencies
        default_coins = [
            ('bitcoin', 'Bitcoin'),
            ('ethereum', 'Ethereum'),
            ('ripple', 'XRP'),
            ('cardano', 'Cardano')
        ]
        
        for coin_id, coin_name in default_coins:
            self.add_cryptocurrency(coin_id, coin_name)
        
        print(f"\n✅ Default coins added: Bitcoin, Ethereum, XRP, Cardano")
        print(f"💡 Tip: You can add more coins using the 'Add' option\n")
        input("Press Enter to continue...")
        
        last_refresh = 0
        
        while True:
            current_time = time.time()
            
            # Auto-refresh at set intervals
            if current_time - last_refresh >= self.refresh_interval:
                prices_data = self.fetch_prices()
                self.display_prices(prices_data)
                last_refresh = current_time
            
            # Handle user input
            try:
                choice = input("\n⚡ Enter command: ").strip().upper()
                
                if choice == 'Q':
                    print("\n👋 Thank you for using Crypto Price Tracker! Goodbye!\n")
                    break
                
                elif choice == 'R':
                    prices_data = self.fetch_prices()
                    self.display_prices(prices_data)
                    last_refresh = current_time
                
                elif choice == 'A':
                    print("\n📝 Add Cryptocurrency")
                    search_term = input("🔍 Enter coin name or symbol: ").strip()
                    
                    if not search_term:
                        print("❌ Invalid input\n")
                        continue
                    
                    print("\n🔍 Searching...")
                    results = self.search_coin(search_term)
                    
                    if not results:
                        print("❌ No coins found. Try a different name.\n")
                        continue
                    
                    print("\n📋 Search Results:")
                    for i, coin in enumerate(results[:10], 1):
                        print(f"{i}. {coin['name']} ({coin['symbol'].upper()}) - ID: {coin['id']}")
                    
                    try:
                        selection = int(input("\n👉 Select coin number (0 to cancel): ")) - 1
                        if 0 <= selection < len(results):
                            coin = results[selection]
                            if self.add_cryptocurrency(coin['id'], coin['name']):
                                print(f"✅ {coin['name']} added successfully!\n")
                            else:
                                print(f"⚠️ {coin['name']} is already being tracked!\n")
                        else:
                            print("❌ Invalid selection\n")
                    except ValueError:
                        print("❌ Invalid input\n")
                
                elif choice == 'D':
                    if not self.cryptocurrencies:
                        print("\n⚠️ No cryptocurrencies to delete\n")
                        continue
                    
                    print("\n🗑️ Remove Cryptocurrency")
                    for i, coin in enumerate(self.cryptocurrencies, 1):
                        print(f"{i}. {coin['name']}")
                    
                    try:
                        selection = int(input("\n👉 Select coin number to delete (0 to cancel): ")) - 1
                        if 0 <= selection < len(self.cryptocurrencies):
                            removed_coin = self.cryptocurrencies[selection]
                            self.remove_cryptocurrency(selection)
                            print(f"✅ {removed_coin['name']} removed successfully!\n")
                        elif selection == -1:
                            continue
                        else:
                            print("❌ Invalid selection\n")
                    except ValueError:
                        print("❌ Invalid input\n")
                
                elif choice == 'T':
                    if not self.cryptocurrencies:
                        print("\n⚠️ No cryptocurrencies to show trends\n")
                        continue
                    
                    print("\n📊 Price Trends")
                    for i, coin in enumerate(self.cryptocurrencies, 1):
                        history_count = len(self.price_history[coin['id']])
                        print(f"{i}. {coin['name']} - {history_count} data points")
                    
                    try:
                        selection = int(input("\n👉 Select coin number to view trend (0 to cancel): ")) - 1
                        if 0 <= selection < len(self.cryptocurrencies):
                            coin = self.cryptocurrencies[selection]
                            self.plot_trend(coin['id'], coin['name'])
                        elif selection == -1:
                            continue
                        else:
                            print("❌ Invalid selection\n")
                    except ValueError:
                        print("❌ Invalid input\n")
                
                elif choice == 'S':
                    self.save_to_csv()
                
                else:
                    print("\n❌ Invalid command. Use: R, A, D, T, S, or Q\n")
                    
            except KeyboardInterrupt:
                print("\n\n👋 Goodbye!\n")
                break
            except Exception as e:
                print(f"\n❌ Unexpected error: {e}\n")

# Entry point
if __name__ == "__main__":
    tracker = CryptoPriceTracker()
    tracker.run()